const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN');
const toast=t=>{const e=$('#toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2400)};
async function api(path,method='GET',data){
  const r=await fetch('/api/admin/'+path,{method,headers:{'Content-Type':'application/json','X-VM-Admin':'1'},body:data?JSON.stringify(data):undefined});
  const d=await r.json().catch(()=>({}));
  if(r.status===401&&path!=='login'){lock();throw Error('Session expired. Please sign in again.')}
  if(!r.ok)throw Error(d.error||'Request failed');return d;
}
const lock=()=>{$('#app').hidden=true;$('#login').hidden=false};
const unlock=()=>{$('#login').hidden=true;$('#app').hidden=false;go('overview')};
const tag=s=>`<span class="tag ${esc(s)}">${esc(String(s).replace('_',' ').toUpperCase())}</span>`;
const items=o=>o.items.map(i=>`${esc(i.name)} ×${i.qty}`).join(', ');
const run=fn=>async(...a)=>{try{await fn(...a)}catch(e){toast(e.message)}};
let tab='overview';
function go(t){tab=t;document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));views[t]().catch(e=>toast(e.message))}
function set(html){$('#view').innerHTML=html}
function orderCard(o){return `<div class="row"><div><b>${esc(o.id)}</b> · ${esc(o.customer_name)} ${tag(o.status)}<br><span class="muted">${items(o)} · ${money(o.total)}${o.coupon?' · coupon '+esc(o.coupon):''}<br>${esc(o.email)} · ${esc(o.phone)} · ${esc(o.location)}<br>${esc(new Date(o.created_at).toLocaleString())}</span>${o.code?`<br><span class="code">${esc(o.code)}</span>`:''}</div></div>`}
function bindStatus(o){document.querySelectorAll('[data-st]').forEach(b=>b.onclick=run(async()=>{await api(`orders/${b.dataset.id}/status`,'POST',{status:b.dataset.st});toast('Order '+b.dataset.st);go(tab)}))}
const views={
async overview(){const s=await api('stats'),by=Object.fromEntries(s.byStatus.map(x=>[x.status,x]));const g=k=>by[k]||{n:0,s:0};
  set(`<h2>Overview</h2><div class="grid"><div class="stat">Awaiting payment<b>${g('awaiting_payment').n}</b></div><div class="stat">Codes to verify<b>${g('payment_submitted').n}</b></div><div class="stat">Verified orders<b>${g('verified').n}</b></div><div class="stat">Verified revenue<b>${money(g('verified').s)}</b></div><div class="stat">Active coupons<b>${s.activeCoupons}</b></div></div>`)},
async verify(){set(`<h2>Verify Payment Code</h2><div class="panel"><div class="form"><input id="vc" maxlength="20" placeholder="VM••••••••••••••••HE" autocomplete="off"><button class="btn" id="vb">Verify</button></div><div id="vr"></div></div>`);
  const check=run(async()=>{const d=await api('verify','POST',{code:$('#vc').value});
    $('#vr').innerHTML=d.valid?`<div class="result ok"><h3>✅ VALID CODE</h3>${orderCard(d)}<div class="form"><button class="sm" data-st="verified" data-id="${esc(d.id)}">Mark payment verified</button><button class="sm red" data-st="rejected" data-id="${esc(d.id)}">Reject</button></div></div>`:'<div class="result bad"><h3>❌ INVALID CODE</h3><span class="muted">No order matches this code.</span></div>';bindStatus()});
  $('#vb').onclick=check;$('#vc').onkeydown=e=>{if(e.key==='Enter')check()}},
async orders(){const rows=await api('orders');set(`<h2>Orders</h2><div class="panel">${rows.map(o=>orderCard(o).replace(/<\/div><\/div>$/,`${o.code?`<div class="form"><button class="sm" data-st="verified" data-id="${esc(o.id)}">Verify</button><button class="sm red" data-st="rejected" data-id="${esc(o.id)}">Reject</button></div>`:''}</div></div>`)).join('')||'<p class="muted">No orders yet.</p>'}</div>`);bindStatus()},
async coupons(){const rows=await api('coupons');
  set(`<h2>Coupons</h2><div class="panel"><h3>Random coupon</h3><div class="form"><input id="rp" type="number" min="1" max="90" placeholder="Discount %"><button class="btn" id="rb">Generate random (6 chars)</button></div><h3>Custom coupon</h3><div class="form"><input id="cc" maxlength="6" placeholder="6-character code"><input id="cp" type="number" min="1" max="90" placeholder="Discount %"><button class="btn ghost" id="cb">Create</button></div>${rows.map(c=>`<div class="row"><div><b class="code">${esc(c.code)}</b> · ${c.discount}% off ${tag(c.active?'verified':'rejected').replace(/VERIFIED|REJECTED/,c.active?'ACTIVE':'INACTIVE')}</div><div><button class="sm" data-t="${esc(c.code)}" data-a="${c.active?0:1}">${c.active?'Deactivate':'Activate'}</button> <button class="sm red" data-d="${esc(c.code)}">Delete</button></div></div>`).join('')||'<p class="muted">No coupons yet.</p>'}</div>`);
  $('#rb').onclick=run(async()=>{const d=await api('coupons/random','POST',{discount:Number($('#rp').value)});toast('Created '+d.code);go('coupons')});
  $('#cb').onclick=run(async()=>{await api('coupons','POST',{code:$('#cc').value,discount:Number($('#cp').value)});toast('Coupon created');go('coupons')});
  document.querySelectorAll('[data-t]').forEach(b=>b.onclick=run(async()=>{await api('coupons/'+b.dataset.t,'PATCH',{active:b.dataset.a==='1'});go('coupons')}));
  document.querySelectorAll('[data-d]').forEach(b=>b.onclick=run(async()=>{if(confirm('Delete coupon '+b.dataset.d+'?')){await api('coupons/'+b.dataset.d,'DELETE');go('coupons')}}))},
async ranks(){const rows=await api('ranks');
  set(`<h2>Ranks (live on the store)</h2><div class="panel">${rows.map(r=>`<div class="edit" data-r="${esc(r.name)}"><b>${esc(r.name)}</b><input data-f="price" type="number" value="${r.price}" aria-label="Price"><input data-f="tier" value="${esc(r.tier)}" aria-label="Tier"><input data-f="description" value="${esc(r.description)}" aria-label="Description"><input data-f="icon" value="${esc(r.icon)}" maxlength="4" aria-label="Icon"><span><button class="sm" data-save>Save</button> <button class="sm ghost" data-act>${r.active?'Hide':'Show'}</button> <button class="sm red" data-del>Delete</button></span></div>`).join('')}<h3>Add rank</h3><div class="form"><input id="nn" placeholder="NAME" maxlength="16"><input id="np" type="number" placeholder="Price ₹"><input id="nt" placeholder="Tier label"><input id="nd" placeholder="Description"><button class="btn" id="na">Add</button></div></div>`);
  const read=el=>Object.fromEntries([...el.querySelectorAll('[data-f]')].map(i=>[i.dataset.f,i.dataset.f==='price'?Number(i.value):i.value]));
  const byName=Object.fromEntries(rows.map(r=>[r.name,r]));
  document.querySelectorAll('[data-r]').forEach(el=>{const n=el.dataset.r,cur=byName[n];
    el.querySelector('[data-save]').onclick=run(async()=>{await api('ranks/'+n,'PUT',{...read(el),active:!!cur.active,sort:cur.sort});toast(n+' saved');go('ranks')});
    el.querySelector('[data-act]').onclick=run(async()=>{await api('ranks/'+n,'PUT',{...read(el),active:!cur.active,sort:cur.sort});go('ranks')});
    el.querySelector('[data-del]').onclick=run(async()=>{if(confirm('Delete rank '+n+'?')){await api('ranks/'+n,'DELETE');go('ranks')}})});
  $('#na').onclick=run(async()=>{await api('ranks','POST',{name:$('#nn').value,price:Number($('#np').value),tier:$('#nt').value,description:$('#nd').value,sort:rows.length+1});toast('Rank added');go('ranks')})},
async settings(){const s=await api('settings');
  set(`<h2>Store settings</h2><div class="panel"><p class="muted">UPI ID shown at payment (optional)</p><div class="form"><input id="su" value="${esc(s.upi_id)}" maxlength="100"></div><p class="muted">Announcement banner on the store (leave empty to hide)</p><div class="form"><input id="sb" value="${esc(s.banner)}" maxlength="160"></div><button class="btn" id="ss">Save settings</button></div>`);
  $('#ss').onclick=run(async()=>{await api('settings','PUT',{upi_id:$('#su').value,banner:$('#sb').value});toast('Settings saved')})}
};
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>go(b.dataset.tab));
$('#logout').onclick=async()=>{await api('logout','POST').catch(()=>{});lock()};
$('#login-form').onsubmit=async e=>{e.preventDefault();$('#login-msg').textContent='';
  try{await api('login','POST',{password:$('#pw').value});$('#pw').value='';unlock()}catch(err){$('#login-msg').textContent=err.message}};
api('me').then(unlock).catch(()=>{});
